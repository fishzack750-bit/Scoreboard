import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

let running = new Map();

world.afterEvents.itemUse.subscribe((event) => {
    const player = event.source;
    const item = event.itemStack;
    if (!item) return;

    if (item.typeId !== "minecraft:diamond_sword") return;

    const menu = new ActionFormData()
        .title("Admin Menu")
        .body("Select option")
        .button("Set Owner")
        .button("Set Admin")
        .button("Set Mod")
        .button("Toggle Action Bar");

    menu.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0) setRank(player, "Owner");
        if (res.selection === 1) setRank(player, "Admin");
        if (res.selection === 2) setRank(player, "Mod");
        if (res.selection === 3) toggleHUD(player);
    });
});

function setRank(player, rank) {
    player.setDynamicProperty("rank", rank);
    player.sendMessage("§aRank set to §e" + rank);
}

function getRank(player) {
    return player.getDynamicProperty("rank") ?? "Player";
}

function toggleHUD(player) {
    if (running.has(player.id)) {
        system.clearRun(running.get(player.id));
        running.delete(player.id);
        player.onScreenDisplay.setActionBar("§cHUD Disabled");
        return;
    }

    let ticks = 0;

    const id = system.runInterval(() => {
        if (!player.isValid()) return;

        ticks++;

        const health = Math.floor(player.getComponent("minecraft:health").currentValue);
        const rank = getRank(player);

        player.onScreenDisplay.setActionBar(
            `§6${rank} §7| §f${player.name} §7| §cHP:${health} §7| §eT:${ticks}`
        );
    }, 20);

    running.set(player.id, id);
}
